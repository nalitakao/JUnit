import static org.junit.Assert.*;

import org.junit.Test;

public class TesteBoasVindas {

	@Test
	public void testeCriaMensagemPadrao() {
		String mensagem = "jeca tatu ";
		BoasVindas mensagemUsuario = new BoasVindas(mensagem);
		String mensagemRetorno = mensagemUsuario.completarMenssagem();
		assertEquals("Ol�! Seja bem vindo ", mensagemRetorno);
	}
	
	@Test
	public void testeExibirMensagem() {
		String mensagem = "jeca urubu ";
		BoasVindas mensagemUsuario = new BoasVindas(mensagem);
		String mensagemRetorno = mensagemUsuario.exibirMenssagem();
		assertEquals(mensagem, mensagemRetorno);
	}

}

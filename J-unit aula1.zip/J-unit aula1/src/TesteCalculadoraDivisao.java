import static org.junit.Assert.*;

import org.junit.Test;

public class TesteCalculadoraDivisao {

	@Test
	public void testeDivisao() {
		int n1 = 16;
		int n2 = 4;
		int resultadoEsperado = 4;
		
		Calculadora cal = new Calculadora();
		int resultadoReal = cal.dividir(n1, n2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

}

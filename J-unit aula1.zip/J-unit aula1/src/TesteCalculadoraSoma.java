import static org.junit.Assert.*;

import org.junit.Test;

public class TesteCalculadoraSoma {

	@Test
	public void testeSomar() {
		int n1 = 2;
		int n2 = 2;
		int resultadoEsperado = 4;
		
		Calculadora calculadora = new Calculadora();
		int resultadoReal = calculadora.somar(n1, n2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

}

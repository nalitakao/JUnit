import static org.junit.Assert.*;

import org.junit.Test;

public class TesteCalculadoraSubtracao {

	@Test
	public void testeSubtracao() {
		int n1 = 8;
		int n2 = 5;
		int resultadoEsperado = 3;
		
		Calculadora calculadora = new Calculadora();
		int resultadoReal = calculadora.subtrair(n1, n2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

}

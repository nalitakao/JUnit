import static org.junit.Assert.*;

import org.junit.Test;

public class TesteMultiplicacao {

	@Test
	public void testeMultiplicacao() {
		int n1 = 5;
		int n2 = 7;
		int resultadoEsperado = 35;
		
		Calculadora cal = new Calculadora();
		int resultadoReal = cal.multiplicar(n1, n2);
		assertEquals(resultadoEsperado, resultadoReal);
	}

}
